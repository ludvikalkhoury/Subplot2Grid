from .Subplot2Grid import Subplot2Grid

__version__ = Subplot2Grid.version
