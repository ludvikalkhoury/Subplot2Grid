"""
Command example:
python -m Subplot2Grid

"""

import tkinter as tk
from .Subplot2Grid import Subplot2Grid

root = tk.Tk()
app = Subplot2Grid(root)
root.mainloop()



